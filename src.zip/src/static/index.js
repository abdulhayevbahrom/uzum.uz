import artelImg from "../assets/artel.png";
import premierImg from "../assets/premier.png";
import samsungImg from "../assets/samsung.png";
import shivakiImg from "../assets/shivaki.png";
import miImg from "../assets/mi.png";
import olgImg from "../assets/olg.png";
import avalonImg from "../assets/avalon.png";
import tecnoImg from "../assets/tecno.png";
import honorImg from "../assets/honor.png";
import huaweiImg from "../assets/huawei.png";
import oppoImg from "../assets/oppo.png";
import realmeImg from "../assets/realme.png";
import ssmartImg from "../assets/ssmart.png";
import vivoImg from "../assets/vivo.png";
import boschImg from "../assets/bosch.png";
import asusImg from "../assets/asus.png";
import instagramLogo from '../assets/instagram.webp'
import facebookLogo from '../assets/facebook.svg'
import telegramLogo from '../assets/telegram.svg'
import okLogo from '../assets/ok.svg'
import tiktokLogo from '../assets/tiktok.svg'

export const DATA = [
  { img: artelImg, title: "Artel", id: 1 },
  { img: premierImg, title: "Premier", id: 2 },
  { img: samsungImg, title: "Samsung", id: 3 },
  { img: shivakiImg, title: "Shivaki", id: 4 },
  { img: miImg, title: "Xiaomi", id: 5 },
  { img: olgImg, title: "LG", id: 6 },
  { img: avalonImg, title: "Avalon", id: 7 },
  { img: tecnoImg, title: "Tecno", id: 8 },
  { img: honorImg, title: "Honor", id: 9 },
  { img: huaweiImg, title: "Huawei", id: 10 },
  { img: oppoImg, title: "Oppo", id: 11 },
  { img: realmeImg, title: "Realme", id: 12 },
  { img: ssmartImg, title: "SSmart", id: 13 },
  { img: vivoImg, title: "Vivo", id: 14 },
  { img: boschImg, title: "Bosch", id: 15 },
  { img: asusImg, title: "Asus", id: 16 },
];
export const INFO = [
  {
    id: 1,
    p: `alifshop.uz– маркетплейс, предоставляющий возможность
    покупателям приобрести широкий спектр товаров быстро и с
    удобством. На alifshop.uz вы сможете найти смартфон,
    компьютер, планшет, телевизор, умные часы и множество других
    гаджетов которых вам так не хватало. На нашем маркетплейсе
    имеется большой выбор электроники, бытовой техники,
    автотоваров и товаров для дома. Мы работаем по всем
    международным стандартам и общепринятым нормам. Найдите нужный
    вам товар на alif shop!`,
    title: "alif shop",
  },
  {
    id: 2,
    p: ` Сегодня, в эпоху высоких технологий, смартфон стал
    неотъемлемой частью нашей повседневной жизни. Благодаря
    приложениям и техническим параметрам современных телефонов,
    смартфоны часто заменяют нам компьютер, фотоаппарат, MP3-Плеер
    и многие другие устройства. Подобные гаджеты стали незаменимой
    деталью нашего быта и в них нуждаются абсолютно все, однако,
    не все могут позволить себе приобрести телефон, заплатив всю
    сумму сразу. Поэтому alif shop предоставляет своим покупателям
    возможность приобрести телефон в рассрочку. Рассрочка позволит
    вам получить любимый гаджет сразу, но произвести оплату
    частями. Преимущество заключаются в том, что не нужно
    откладывать большую сумму на протяжении долгого времени.`,
    title: "Телефоны в рассрочку",
  },
  {
    id: 3,
    p: `
    ПК дают нам возможность качественно выполнять нашу работу и
    одновременно скрасить наш досуг. К примеру, при помощи
    ноутбука можно оперативно работать из любой точки мира,
    выполняя самую разную работу, начиная с простых отчетов в Word
    и заканчивая сложным проектом в 3D-Max. Ноутбук – лучший друг
    фрилансера. В тоже время компьютеры позволяют людям отдохнуть
    от повседневной рутины и провести свой досуг за любимой игрой,
    просмотром фильма или серфингом в социальных сетях. Любители
    устройств, обладающих мобильностью, регулярно задумываются о
    том, чтобы взять ноутбук в кредит, в то время как любители
    более мощных ПК хотят взять стационарный компьютер в кредит.
    На alifshop.uz у вас есть возможность взять понравившийся вам
    ноутбук в рассрочку. Выполняйте свою работу и проводите свой
    досуг с приглянувшимся вам ноутбуком!
    `,
    title: "Ноутбуки в рассрочку",
  },
  {
    id: 4,
    p: `
    Помимо электроники, на нашем маркетплейсе имеется широкий
    ассортимент бытовой техники: газовые плиты, грили,
    холодильники, стиральные машины, утюги, кондиционеры и много
    других незаменимых вещей. alif shop предоставляет своим
    покупателям возможность взять понравившеюся бытовую технику в
    рассрочку!
    `,
    title: "Техника в рассрочку",
  },
];
export const LOGO = [
  {img: instagramLogo, id: 1},
  {img: facebookLogo, id: 2},
  {img: telegramLogo, id: 3},
  {img: tiktokLogo, id: 4},
] 