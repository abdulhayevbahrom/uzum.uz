import './App.css';
import Footer from './components/footer/Footer';

function App() {
  return (
    <div className="App">
      <Footer/>
    </div>
  );
}

export default App;
